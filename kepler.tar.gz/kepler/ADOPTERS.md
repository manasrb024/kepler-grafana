# Kepler Adopters

The list of organisations who are using Kepler can be found at
<https://sustainable-computing.io/project/adopters/>.

To join the adopters list, please follow
[these instructions](https://sustainable-computing.io/project/contributing/).
